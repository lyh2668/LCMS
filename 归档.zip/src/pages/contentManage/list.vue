<template lang="html">
  <div class="">
    这是列表页面
  </div>
</template>

<script type="text/ecmascript-6">
export default {
  name: 'CMList'
}
</script>

<style lang="scss" scoped>
</style>
