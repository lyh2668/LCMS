<template lang="html">
  <div class="components-header">
    这是头部
  </div>
</template>

<script type="text/ecmascript-6">
export default {
}
</script>

<style lang="scss" scoped>
@import '../../common/style/var.scss';
.components-header {
  width: 100%;
  height: 60px;
  line-height: 60px;
  color: #fff;
  background: $header-color;
}
</style>
