<template lang="html">
  <div class="">
    publish
  </div>
</template>

<script type="text/ecmascript-6">
export default {
  name: 'CMPublish'
}
</script>

<style lang="scss" scoped>
</style>
