<template lang="html">
  <div class="l-menu">
    <el-menu
      :unique-opened="uniqueOpened"
      :router="router"
      :default-active="defaultActive"
      :collapse="collapse"
      class="el-menu-vertical-demo"
      @open="handleOpen"
      @close="handleClose">
      <l-menu-item :menus="menus"></l-menu-item>
    </el-menu>
  </div>
</template>

<script type="text/ecmascript-6">
import LMenuItem from './menuItem.vue'
export default {
  name: 'LMenu',
  components: {
    LMenuItem
  },
  props: {
    uniqueOpened: {
      type: Boolean,
      defaultValue: false
    },
    defaultActive: {
      type: String,
      defaultValue: ''
    },
    router: {
      type: Boolean,
      defaultValue: false
    },
    menus: {
      type: Array
    },
    collapse: {
      type: Boolean,
      defaultValue: false
    }
  },
  created () {
    console.log('menu created: ', this.menus)
  },
  methods: {
    handleOpen: function (key, keyPath) {
      console.log(key, keyPath)
    },
    handleClose: function (key, keyPath) {
      console.log(key, keyPath)
    }
  }
}
</script>

<style lang="scss">
.l-menu {
  .el-menu-vertical-demo:not(.el-menu--collapse) {
    width: 200px;
  }
  .el-menu--collapse .el-submenu>.el-submenu__title .el-submenu__icon-arrow {
    display: none;
  }
  .el-menu--collapse .el-submenu>.el-submenu__title span {
    height: 0;
    width: 0;
    overflow: hidden;
    visibility: hidden;
    display: inline-block;
  }
}
</style>
