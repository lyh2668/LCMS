const state = {
  routesMatched: []
}

const getters = {

}

const mutations = {

}

const actions = {

}

const routes = {
  state,
  getters,
  mutations,
  actions
}

export default routes
