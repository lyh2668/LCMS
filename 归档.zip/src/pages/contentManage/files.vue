<template lang="html">
  <div class="">
    这是文件页面
  </div>
</template>

<script type="text/ecmascript-6">
export default {
  name: 'CMFiles'
}
</script>

<style lang="scss" scoped>
</style>
