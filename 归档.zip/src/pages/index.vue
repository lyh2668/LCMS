<template lang="html">
  <div class="index-container">
    <div class="left-container">
      <l-brand title="政策树后台" :img-src="logo" :collapse="isCollapse"></l-brand>
      <l-menu
        class="side-menu"
        :menus="routes"
        :default-active="$route.path"
        router
        unique-opened
        :collapse="isCollapse"></l-menu>
    </div>
    <div class="right-container">
      <!-- <l-main></l-main> -->
      <l-header></l-header>
      <l-main-header :items="routesMatched"></l-main-header>
      <button @click="onCollapse">点我测试menu的收缩和展开</button>
      <router-view></router-view>
    </div>
    </div>
  </div>
</template>

<script type="text/ecmascript-6">
import LHeader from 'components/layouts/header'
import LMenu from 'components/menu'
import LMainHeader from 'components/layouts/mainHeader'
import LBrand from 'components/layouts/brand'
import { mapGetters } from 'vuex'
import logo from '@/assets/logo/sh_light.png'
export default {
  name: 'Index',
  components: {
    LHeader,
    LMenu,
    LMainHeader,
    LBrand
  },
  computed: {
    ...mapGetters([
      'routes'
    ])
  },
  data () {
    return {
      isCollapse: false,
      routesMatched: this.$route.matched,
      logo: logo
    }
  },
  methods: {
    onCollapse: function () {
      this.isCollapse = !this.isCollapse
    }
  },
  watch: {
    '$route': function () {
      this.routesMatched = this.$route.matched
    }
  }
}
</script>

<style lang="scss">
.index-container {
  position: absolute;
  width: 100%;
  height: 100%;
  display: flex;
  overflow: hidden;
  .left-container {
    .brand {
      height: 60px;
      line-height: 60px;
    }
    .side-menu {
      height: 100%;
      background: #eef1f6;
      &::-webkit-scrollbar { display:none }
    }
  }

  .right-container {
    width: 100%;
    transition: width 0.28s ease-out;
  }
}
</style>
