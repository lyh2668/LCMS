import adminUser from './adminUser'
import permission from './permission'
import routes from './routes'

export default {
  adminUser,
  permission,
  routes
}
