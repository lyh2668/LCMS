<template lang="html">

</template>

<script type="text/ecmascript-6">
export default {
  name: 'ContentManage'
}
</script>

<style lang="scss" scoped>
</style>
