<template lang="html">
  <div>
    这是detail页面
  </div>
</template>

<script type="text/ecmascript-6">
export default {
  name: 'CMDetail'
}
</script>

<style lang="scss" scoped>
</style>
